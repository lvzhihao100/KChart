package com.github.tifezh.kchartlib.chart.entity;

/**
 * k线实体接口
 * Created by tifezh on 2016/6/9.
 */

public interface IKLine extends ICandle, IBOLL, IMACD, IKDJ, IRSI,IVolume {
}
