package com.github.tifezh.kchartlib.chart.entity;

public class ItemDrawBean {
}
